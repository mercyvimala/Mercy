# Student digital portfolio 2

A Pen created on CodePen.

Original URL: [https://codepen.io/mercy-2006/pen/MYaZXgN](https://codepen.io/mercy-2006/pen/MYaZXgN).

